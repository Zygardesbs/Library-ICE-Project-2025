package users;

public interface Accounts{
    String getName();
    boolean isAdmin();
    void update(String name);
}
