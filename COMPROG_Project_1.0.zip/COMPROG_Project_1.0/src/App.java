public class App {
    public static void main(String[] args) {
        LibraryApp.run();
    }
}
